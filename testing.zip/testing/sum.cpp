#include <iostream>
#include <stdlib.h>
int main(int argc, char *argv[]){
   double a,b;
   a=atoi (argv[1]);
   b=atoi (argv[2]);
   std::cout<<a+b<<"\n";
   return 0;
}
