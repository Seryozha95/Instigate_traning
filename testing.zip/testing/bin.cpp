#include <iostream>
#include <stdlib.h>
int main(int argc, char *argv[]){
   int num; 
   int mod; 
   long int result=0;
   long int ten=1;

   num = atoi (argv[1]);
   while (num>0){
   mod=num%2;
   num=num/2;
   result=result+mod*ten;
   ten=ten*10;
   }
   std::cout<<result<<"\n";
   return 0;
}
