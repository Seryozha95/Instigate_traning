#!/bin/bash
echo "If run factorial.cpp  enter        fact"
echo "If run binar.cpp  enter            bin "
echo "If run sum.cpp  enter              sum"
read mutq 
function testing() {
	g++ $run_cpp.cpp -o $run_cpp.exe
	./$run_cpp.exe ${input[1]} ${input[2]}
	output=$(./$run_cpp.exe ${input[1]} ${input[2]})
}
while read line
	do
		IFS=' ' read -ra input <<< "$line"
run_cpp=${input[0]}
   		 if [[ "$mutq" == "$run_cpp" ]]
			then
				testing
				if [[ $output = ${input[3]} || $output = ${input[2]} ]]
					then
						echo "Test state pass!!!"
               else
                  echo "Test state fail!!!"
				fi
		 fi
done < test.txt

